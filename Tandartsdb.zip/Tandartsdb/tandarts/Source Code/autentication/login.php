<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../Style/login.css">
    <title>Login</title>
</head>
<body>
    <main>
    <a href="login_patienten.php"><div class="login">
            <div>
               <p>Login as Patient</p>
            </div>
        </div></a>
        <a href="login-tandarts.php"><div class="login">
            <div>
                <p>Login as Dentist</p>
            </div>
        </div></a>
    </main>
</body>
</html>