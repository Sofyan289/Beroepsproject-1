let footer = `
    <ul class='footer'>
        <li class='menu_item'><a href='../Contact.php'><p>Contact</p></a></li>
        <li class='menu_item'><a href='../AboutUs.php'><p>About Us</p></a></li>
        <li class='menu_item'><a href='../privacyPolicy.php'><p>Privacy Policy</p></a></li>
        <li class='menu_item'><a href='../Terms.php'><p>Terms & Conditions</p></a></li>
    </ul>
    <p>&copy; 2024 Tiny Tooth Dental. All Rights Reserved.</p>
`;

document.getElementById("footer").innerHTML = footer;