<?php
require_once("session_manager.php");
require_once("db.php");
class Review
{

    public $dbh;
    public $employeeTable = "employees";
    public $appointmentsTable = "appointments";
    public $reviewTable = "employee_reviews";

    public $patientsTable = "patients";

    public function __construct(DB $dbh)
    {
        $this->dbh = $dbh;
    }
}
$myDB = new DB();
$Review = new Review($myDB);